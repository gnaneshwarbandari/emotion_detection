#! /usr/bin/env python3
import pyaudio
import wave
import threading
from tkinter import *
import speech_recognition as sr
import rospy
from geometry_msgs.msg import Twist
import time

rospy.init_node('voice_command')
rate=rospy.Rate(4)
pub=rospy.Publisher('/cmd_vel', Twist, queue_size=1)

move=Twist()

r = sr.Recognizer()

CHUNK = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
audio = pyaudio.PyAudio()
frames = []
root = Tk(className='Voice Controlled Robot')
root.geometry("400x220")

def send(cmd):
    print(cmd)
    move.linear.x = 0.0
    move.angular.z = 0.0
    if cmd == 'f':
        move.linear.x = 1.0
    elif cmd == 'b':
        move.linear.x = -1.0
    elif cmd == 'l':
        move.angular.z = 1.0
    elif cmd == 'r':
        move.angular.z = -1.0
    pub.publish(move)
    time.sleep(3)
    move.linear.x = 0.0
    move.angular.z = 0.0
    pub.publish(move)

def process_audio(f):
    with sr.AudioFile(f) as source:
        audio_text = r.listen(source)
    try:
        text = r.recognize_google(audio_text)
        print('Text: {}'.format(text))
        t = text
    except:
        print('Sorry, could not recognize the audio.')
        t = "Couldnt process the data"
    status.configure(text="Command Sent: "+t, font= ('Aerial', 12))
    if "forward" in text:
            cd = 'f'
    elif "backward" in text:
        cd = 'b'
    elif "left" in text:
        cd = 'l'
    elif "right" in text:
        cd = 'r'
    else:
        cd = ''
    send(cd)

def start_recording():
    print("Started")
    frames = []
    stream = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)
    start_button.config(state='disabled')
    stop_button.config(state='normal')
    
    while True:
        data = stream.read(CHUNK)
        frames.append(data)
        if stop_button['state'] == 'disabled':
            break
    
    stream.stop_stream()
    stream.close()
    
    wf = wave.open('recording.wav', 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(audio.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    wf.close()

    process_audio('recording.wav')
    print("End")
    
def stop_recording():
    stop_button.config(state='disabled')
    start_button.config(state='normal')

root.grid_rowconfigure(0, weight=1)
root.grid_columnconfigure(0, weight=1)

top = Frame(root, bg='white', width= 400, height=50)
middle = Frame(root, bg='white', width= 400, height=100)
bottom = Frame(root, bg='white', width= 400, height=150)

title = Label(top,  justify="center", bg='white', fg='#060', text= "Voice Input", font= ('Aerial', 12, 'bold'))
title.pack(side = LEFT, expand = True, fill = BOTH, padx=15, pady=30)

start_button = Button(middle, text='Start', bg='#aaf', command=lambda: threading.Thread(target=start_recording).start())
start_button.pack()

stop_button = Button(middle, text='Stop', bg='#aaf', command=stop_recording, state='disabled')
stop_button.pack()

status = Label(bottom,  justify="center", bg='white',text= "Sending command", font= ('Aerial', 10))
status.pack(side = LEFT, expand = True, fill = BOTH, padx=15, pady=30)

top.grid(row=1, column=0, sticky="ewns")
middle.grid(row=2, column=0, sticky="ewns")
bottom.grid(row=3, column=0, sticky="ewns")

root.mainloop()
audio.terminate()
