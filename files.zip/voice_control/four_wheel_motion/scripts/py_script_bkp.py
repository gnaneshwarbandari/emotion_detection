#! /usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
import time

rospy.init_node('voice_command')
rate=rospy.Rate(4)
pub=rospy.Publisher('/cmd_vel', Twist, queue_size=1)

move=Twist()

def move_func(cmd):
    print(cmd)
    move.linear.x = 0.0
    move.angular.z = 0.0
    if cmd == 'f':
        move.linear.x = 1.0
    elif cmd == 'b':
        move.linear.x = -1.0
    elif cmd == 'l':
        move.angular.z = 1.0
    elif cmd == 'r':
        move.angular.z = -1.0
    pub.publish(move)
    time.sleep(3)
    move.linear.x = 0.0
    move.angular.z = 0.0
    pub.publish(move)



while not rospy.is_shutdown():
    # after setting the speed from 0.4 to 0 to -0.4 back to 0, letting the robot know its speed is the final value, 0
    cmd_txt = input("Enter the command: ")
    move_func(cmd_txt)
    rate.sleep()